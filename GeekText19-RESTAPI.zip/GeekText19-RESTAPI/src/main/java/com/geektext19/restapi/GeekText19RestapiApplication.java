package com.geektext19.restapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GeekText19RestapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(GeekText19RestapiApplication.class, args);
	}

}
